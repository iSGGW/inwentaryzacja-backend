/*import org.springframework.beans.factory.annonation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
package com.example.postgresql.model;*/
import java.util.Objects;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Column;
import javax.persitance.Table;
import javax.persistence.OneToOne;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;

@Entity
@Table(name="Wydzialy_SGGW")
public class Wydzial
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY);
	@Column(name= "ID_Wydzialu")
	private int id_wydzialu;
	
	@Column(name="Nazwa_Wydzialu")
	private String nazwa_wydzialu;
	
	@Column(name="NR_budynku")
	private int nr_budynku;
	
	public Wydzial(int id_wydzialu, String nazwa_wydzialu, int nr_budynku)
	{
		this.id_wydzialu = id_wydzialu;
		this.nazwa_wydzialu = nazwa_wydzialu;
		this.nr_budynku = nr_budynku;
	}
	
	public int getIdWydzialu() {return id_wydzialu;}
	public String getNazwa() {return nazwa_wydzialu;}
	public int getBudynek() {return nr_budynku;}
	
	public int setIdWydzialu(int id_wydzialu) {return this.id_wydzialu;}
	public String setNazwa(String Nazwa_Wydzialu) {return this.nazwa_wydzialu;}
	public int setBudynek(int nr_budynku) {if (nr_budynku > 0)return this.nr_budynku;}
	
	@Override
	public String toString()
	{
		final StringBuilder sb = new StringBuilder("Wydział{");
		sb.append("id_wydzialu= ").append(id_wydzialu);
		sb.append("nazwa wydziału= ".append(nazwa_wydzialu);
		sb.append("numer budynku = ").append(nr_budynku);
		sb.append("}");
		return sb.toString();
	}
}