import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.Column;
import javax.persistence.Table;
import javax.persistence.ManyToOne;

@Entity
@Table(name="Sprzet")
public class Sprzet
{
	@ManyToOne
	@JoinColumn(name = "ID_Wydzialu")
	private Set<Wydzial> wydzialy;
	
	@Id
	@Column(name="ID_Sprzetu")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	@Column(name="Nazwa_sprzetu")
	private String nazwa;
	
	@Column(name="Kod_kreskowy")
	private String kod;
	
	@Column(name="Id_Wydzialu")
	private int id_wydzialu;
	
	@Column(name="sala")
	private String sala;
	
	@Column(name="status")
	private String status;
	
	@Override
	public String toString()
	{
		final StringBuilder sb = new StringBuilder("Sprzet{");
		sb.append("ID_Sprzetu= ").append(id);
		sb.append("kod sprzetu= ".append(kod);
		sb.append("id wydzialu= ").append(id_wydzialu);
		sb.append("sala= ").append(sala);
		sb.append("status= ").append(status);
		sb.append("}");
		return sb.toString();
	}
}