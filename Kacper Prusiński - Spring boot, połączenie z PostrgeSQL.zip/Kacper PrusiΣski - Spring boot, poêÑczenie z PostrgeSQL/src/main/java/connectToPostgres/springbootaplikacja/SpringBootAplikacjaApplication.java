package connectToPostgres.springbootaplikacja;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.jdbc.core.JdbcTemplate;
import java.util.scanner;
import org.springframework.boot.CommandLineRunner;
import org.springframework.beans.factory.annonation.Autowired;
package com.examples.postgres;

@SpringBootApplication
public class SpringBootAplikacjaApplication implements CommandLineRunner{
	
	@Autowired
	private WydzialRepository wydzialy;
	
	public static void main(String[] args) {
		SpringApplication.run(SpringBootAplikacjaApplication.class, args);
	}
	
	@Override
	public void run(String... args) throw Exception
	{
		List<Wydzial> students = wydzialy.findAll();
		student.forEach(System.out::println);
	}
}