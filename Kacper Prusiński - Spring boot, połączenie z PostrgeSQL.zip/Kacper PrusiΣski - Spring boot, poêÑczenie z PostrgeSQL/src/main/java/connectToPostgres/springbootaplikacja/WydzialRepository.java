package net.codejava;

import org.springframework.data.repository.JpaRepository;

public interface WydzialRepository extends JpaRepository<Wydzial, Integer>
{
	
}