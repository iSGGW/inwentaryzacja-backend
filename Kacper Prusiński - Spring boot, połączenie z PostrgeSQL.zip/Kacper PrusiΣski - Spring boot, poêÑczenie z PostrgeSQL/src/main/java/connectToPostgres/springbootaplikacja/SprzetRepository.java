package net.codejava;

import org.springframework.data.repository.JpaRepository;

public interface SprzetRepository extends JpaRepository<Sprzet, Integer>
{
	
}