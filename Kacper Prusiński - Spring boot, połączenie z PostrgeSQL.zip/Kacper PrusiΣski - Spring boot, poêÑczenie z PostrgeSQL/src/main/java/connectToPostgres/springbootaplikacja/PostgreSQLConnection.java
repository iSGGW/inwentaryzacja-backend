import com.example.postgresql;

import java.sql.SQLException;
import java.util.Scanner;

public class PostgreSQLConnection
{
	private String database_NAME;
	private String host = "jdbc:postgresql://localhost:5432/"+database_NAME;
	private String username;
	private String password;
	
	public PostgreSQLConnection(String database_NAME, String host, String username, String password)
	{
		this.database_NAME = database_NAME;
		this.host = host;
		this.username = username;
		this.password = password;
	}
	
	public String getDBname() {return this.database_NAME;}
	public String getHost() {return this.host;}
	public String getUsername() {return this.username;}
	public String getPassword() {return this.password;}
	
	
}