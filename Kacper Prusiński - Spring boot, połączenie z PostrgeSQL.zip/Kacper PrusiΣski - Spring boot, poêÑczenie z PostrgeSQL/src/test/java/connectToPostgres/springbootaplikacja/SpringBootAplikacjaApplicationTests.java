package connectToPostgres.springbootaplikacja;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootAplikacjaApplicationTests {

	@Test
	void contextLoads() {
	}

}
